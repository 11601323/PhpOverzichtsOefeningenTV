<?php 
// naam: 

class Message{
	private $id;
	private $contents;

}
