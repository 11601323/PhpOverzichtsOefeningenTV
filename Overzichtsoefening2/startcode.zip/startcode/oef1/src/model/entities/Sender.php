<?php 
// naam: 

class Sender{
	private $id;
	private $name;
	private $messages;


}
