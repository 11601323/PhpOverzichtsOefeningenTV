<?php 
// naam: 

class SenderRepository{
	private $pdo;

}
